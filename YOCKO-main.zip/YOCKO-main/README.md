# YOCKO
geometrY Hartree-FOCK Optimisation
